-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Feb 10, 2021 at 01:08 PM
-- Server version: 5.7.32
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `transpedia`
--

-- --------------------------------------------------------

--
-- Table structure for table `driver_active`
--

CREATE TABLE `driver_active` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `latitude` decimal(8,6) DEFAULT NULL,
  `longitude` decimal(9,6) DEFAULT NULL,
  `bearing` float DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `driver_active`
--

INSERT INTO `driver_active` (`id`, `user_id`, `active`, `latitude`, `longitude`, `bearing`, `created_at`, `updated_at`) VALUES
(24, 31, 1, '-6.216766', '106.938067', 0, '2021-02-09 22:13:38', '2021-02-09 22:13:38');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint(20) NOT NULL,
  `driver_id` bigint(60) DEFAULT NULL,
  `passenger_id` bigint(60) DEFAULT NULL,
  `destination` text,
  `start` text,
  `price` bigint(200) DEFAULT NULL,
  `status` int(200) DEFAULT NULL,
  `distance` bigint(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `driver_id`, `passenger_id`, `destination`, `start`, `price`, `status`, `distance`, `created_at`, `updated_at`) VALUES
(8, NULL, 32, '{\"location\":{\"latitude\":-6.228721,\"longitude\":106.8978988,\"bearing\":0.0},\"know_address\":\"tempat ngopi\"}', '{\"location\":{\"latitude\":-6.2167661,\"longitude\":106.9380667,\"bearing\":0.0},\"know_address\":\"tempat makan\"}', 50000, 3, 40000, '2021-02-10 08:26:41', '2021-02-10 08:31:00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(500) NOT NULL,
  `fcm_token` varchar(500) DEFAULT NULL,
  `expired` bigint(20) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `user_type` int(11) NOT NULL DEFAULT '1',
  `plate_number` varchar(50) DEFAULT NULL,
  `external` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `fcm_token`, `expired`, `name`, `email`, `phone`, `address`, `user_type`, `plate_number`, `external`, `created_at`, `updated_at`) VALUES
(28, '081287903894', '+TU/3do/Qpm7HQmESmBMBQ==', 'fX9po4jPT7Kiot8e2I-baO:APA91bHnlfomUm32YQ1gMSAvVxMpyRcCnniGMbazl4wh6caRNu1DxCVw0Ss9H0y0CVaIDFFe0yRArCa1ee8XEEojGtUtwXv6rMlty6MNqGjvZKHr2cRoDa5BkdXZeEwSF9nf7_h0Hsuc', 1612014340000, 'utsman', 'utsman@mail.com', '081287903894', '', 1, NULL, NULL, '2021-01-21 08:21:08', '2021-01-25 04:27:21'),
(29, '0812111111', 'rJPLrOFNXwmtMWqKVWTzQA==', 'ebtVKp5BQwOFBrUaVPe7vV:APA91bHb9HGKZnvK9uiqAMvYcau3odmw2ZVdVz-5iZFi-UEk8O7qC6X18fpDc_IJKi6RK8_ahb200BvLZ_UxQQHVIRoM1QBf3OVam-x-H5NVKxKm3WBdS-C1iwGKmMzVq6CA3FhHcHaP', 1613512102000, 'salim', 'salim@mail.com', '0812111111', '', 0, 'b 4543 dsf', 'honda', '2021-01-21 08:23:05', '2021-02-09 21:48:23'),
(30, NULL, 'rJPLrOFNXwmtMWqKVWTzQA==', NULL, 1613512831000, NULL, NULL, '0812333333', NULL, 1, NULL, NULL, '2021-02-09 21:57:37', '2021-02-09 22:00:31'),
(31, NULL, 'rJPLrOFNXwmtMWqKVWTzQA==', 'fX9po4jPT7Kiot8e2I-baO:APA91bHnlfomUm32YQ1gMSAvVxMpyRcCnniGMbazl4wh6caRNu1DxCVw0Ss9H0y0CVaIDFFe0yRArCa1ee8XEEojGtUtwXv6rMlty6MNqGjvZKHr2cRoDa5BkdXZeEwSF9nf7_h0Hsuc', 1613551873000, NULL, NULL, '0812444444', NULL, 0, NULL, NULL, '2021-02-09 21:59:14', '2021-02-10 08:51:13'),
(32, 'anjay', 'rJPLrOFNXwmtMWqKVWTzQA==', 'ebtVKp5BQwOFBrUaVPe7vV:APA91bHb9HGKZnvK9uiqAMvYcau3odmw2ZVdVz-5iZFi-UEk8O7qC6X18fpDc_IJKi6RK8_ahb200BvLZ_UxQQHVIRoM1QBf3OVam-x-H5NVKxKm3WBdS-C1iwGKmMzVq6CA3FhHcHaP', 1613551899000, 'anjay subhan', 'anjay@gmail.com', '0812999999', 'buaran', 1, NULL, NULL, '2021-02-09 22:02:49', '2021-02-10 08:51:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `driver_active`
--
ALTER TABLE `driver_active`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `driver_active`
--
ALTER TABLE `driver_active`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `driver_active`
--
ALTER TABLE `driver_active`
  ADD CONSTRAINT `driver_active_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
